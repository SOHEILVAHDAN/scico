Put your renders here:
- 01-hero.jpg (2400px wide)
- 02-landscape.jpg
- 03-village.jpg
- 04-cheese-01.jpg, 04-cheese-02.jpg etc
- 06-form.jpg
- 08-living.jpg
- 09-kitchen-01.jpg, 09-kitchen-02.jpg, 09-kitchen-03.jpg
- 10-bedroom.jpg
- 12-seasons-morning / noon / golden / night

Then in index.html replace:
<!-- REPLACE: ./images/01-hero.jpg -->
src="https://images..."
with
src="./images/01-hero.jpg"
