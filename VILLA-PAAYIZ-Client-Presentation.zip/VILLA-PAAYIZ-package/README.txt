VILLA PAAYIZ — Architectural Presentation
Keleston / Shiraz / Iran

HOW TO USE:
1. Double click index.html — works offline
2. To replace images, edit index.html search for <!-- REPLACE -->
   Example: change 
   https://images.unsplash.com/... 
   to 
   ./images/exterior-01.jpg
3. Put your renders in /images/ folder

PROJECT INFO:
- 230m2, White monolithic bar 32m x 7.2m x 3.4m
- Structure: Steel frame, White mineral render, Shiraz limestone, Walnut
- 13 chapters: Landscape -> Memory -> Tradition -> Concept -> Architecture -> Interior -> Life -> Time -> Memory

CONTACT TEMPLATE:
Studio Paayiz — hello@villapaayiz.com

نحوه استفاده:
1- روی index.html دوبار کلیک کنید
2- برای عکسهای خودتون، پوشه images رو پر کنید و داخل html لینکها رو عوض کنید
3- رنگها از بخش :root در CSS قابل تغییره

(c) 2026 — Confidential Client Presentation
